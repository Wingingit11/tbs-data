#!/usr/bin/env node
/* Machine source verification.
 *
 * This is the safeguard that makes autonomous drafting safe. A model asked to
 * research and draft offline can produce a fluent question with a plausible but
 * wrong or non-existent URL, and schema validation cannot tell the difference.
 * So every candidate's source is FETCHED and corroborated before approval:
 *
 *   1. the URL must resolve (HTTP 200)
 *   2. the host must be on the allow-list of authoritative domains
 *   3. the page text must corroborate the claim - the distinctive terms of the
 *      answer and reveal must actually appear on the page
 *
 * A record that fails any of these is REJECTED, never downgraded. This turns
 * "the model says it checked" into "the artifact was checked".
 *
 *   node tools/flip-verify-sources.js batches/batch-002.json
 */
"use strict";
var fs = require("fs"), path = require("path"), https = require("https");
var engine = require("./flip-engine");

/* Authoritative hosts. Anything else is rejected outright, which also stops a
 * drafting model quietly substituting a blog for a heritage register. */
var ALLOW = [
  "heritage.brisbane.qld.gov.au", "brisbane.qld.gov.au", "www.brisbane.qld.gov.au",
  "apps.des.qld.gov.au", "environment.des.qld.gov.au", "www.qld.gov.au",
  "heritage.qld.gov.au", "www.slq.qld.gov.au", "slq.qld.gov.au",
  "www.statelibrary.qld.gov.au", "trove.nla.gov.au", "nla.gov.au",
  "www.qm.qld.gov.au", "www.museum.qld.gov.au", "visitbrisbane.com.au",
  "www.visitbrisbane.com.au", "translink.com.au", "www.translink.com.au",
  "queenslandplaces.com.au", "www.uq.edu.au", "espace.library.uq.edu.au"
];

function fetchText(url, redirects) {
  redirects = redirects || 0;
  return new Promise(function (resolve) {
    if (redirects > 4) return resolve({ status: 0, text: "", note: "too many redirects" });
    var req = https.get(url, { headers: { "User-Agent": "flip-source-verifier/1.0" } }, function (res) {
      if ([301, 302, 303, 307, 308].indexOf(res.statusCode) >= 0 && res.headers.location) {
        res.resume();
        var next = new URL(res.headers.location, url).toString();
        return resolve(fetchText(next, redirects + 1));
      }
      var body = "";
      res.setEncoding("utf8");
      res.on("data", function (c) { if (body.length < 400000) body += c; });
      res.on("end", function () { resolve({ status: res.statusCode, text: body, finalUrl: url }); });
    });
    req.on("error", function (e) { resolve({ status: 0, text: "", note: e.message }); });
    req.setTimeout(15000, function () { req.destroy(); resolve({ status: 0, text: "", note: "timeout" }); });
  });
}

function strip(html) {
  return html.replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ").replace(/&nbsp;/g, " ")
    .replace(/\s+/g, " ").toLowerCase();
}
var STOP = /^(the|a|an|of|in|on|at|to|for|and|or|was|were|is|are|by|with|from|its|it|that|this|which|what|who|when|brisbane|queensland)$/;
function keyTerms(s) {
  return Array.from(new Set((s || "").toLowerCase().replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/).filter(function (w) { return w.length > 3 && !STOP.test(w); })));
}

/* Corroboration, v2.
 *
 * v1 asked "do the answer's terms and years appear on this page". That is weak
 * evidence: a heritage page about a suburb mentions many buildings and many
 * years, so a question about the WRONG building can pass merely because both
 * names and both dates happen to occur somewhere on it.
 *
 * v2 asks three harder questions:
 *
 *   PROXIMITY   - the answer and its year must co-occur inside one window of
 *                 text, not merely both exist on a 40kb page.
 *   DISCRIMINATION - the page must support the CORRECT option distinctly better
 *                 than the distractor. If it supports both about equally, the
 *                 source does not establish the answer and the question is
 *                 ambiguous. Reject either way.
 *   IDENTITY    - the page must actually be the cited document, checked against
 *                 <title>, not just some page on an approved domain.
 *
 * This still cannot judge truth. It judges whether the cited page demonstrably
 * establishes this specific proposition, which is the part a drafting model
 * can most easily get wrong or invent.
 */
var WINDOW = 600;

function windowsContaining(text, term) {
  var out = [], i = text.indexOf(term);
  while (i >= 0 && out.length < 40) {
    out.push(text.slice(Math.max(0, i - WINDOW / 2), i + term.length + WINDOW / 2));
    i = text.indexOf(term, i + term.length);
  }
  return out;
}
function supportScore(text, label) {
  var terms = keyTerms(label);
  if (!terms.length) return 0;
  return terms.filter(function (t) { return text.indexOf(t) >= 0; }).length / terms.length;
}

function corroborate(pageText, pageTitle, rec) {
  var q = engine.normalise(rec);
  var opts = q.options || [];
  var right = opts.filter(function (o) { return o && o.id === q.correctOptionId; })[0];
  var wrong = opts.filter(function (o) { return o && o.id !== q.correctOptionId; })[0];
  var notes = [];
  if (!right || !wrong) return { ok: false, notes: ["options malformed"] };

  // IDENTITY
  var titleTerms = keyTerms(q.sourceTitle);
  var titleHits = titleTerms.filter(function (t) { return (pageTitle || "").indexOf(t) >= 0; }).length;
  var identityOk = !titleTerms.length || titleHits / titleTerms.length >= 0.4 ||
    supportScore(pageText.slice(0, 4000), q.sourceTitle) >= 0.6;
  if (!identityOk) notes.push("page does not appear to be the cited document (title mismatch)");

  // PROXIMITY - every year in the reveal must sit near the answer, not just on the page
  var years = (q.reveal.match(/\b(1[6-9]\d{2}|20\d{2})\b/g) || []);
  var anchor = keyTerms(right.label).sort(function (a, b) { return b.length - a.length; })[0] || "";
  var proximityOk = true;
  if (years.length && anchor) {
    var wins = windowsContaining(pageText, anchor);
    years.forEach(function (y) {
      if (!wins.some(function (w) { return w.indexOf(y) >= 0; })) {
        proximityOk = false;
        notes.push("year " + y + " never appears near \"" + anchor + "\" on the page");
      }
    });
  } else if (years.length) {
    proximityOk = years.every(function (y) { return pageText.indexOf(y) >= 0; });
    if (!proximityOk) notes.push("a year in the reveal is absent from the page");
  }

  // DISCRIMINATION - the source must pick a side
  var sRight = supportScore(pageText, right.label);
  var sWrong = supportScore(pageText, wrong.label);
  var discriminates = sRight >= 0.5 && sRight - sWrong >= 0.34;
  if (!discriminates) {
    notes.push("source does not distinguish the options (correct " + sRight.toFixed(2) +
      " vs distractor " + sWrong.toFixed(2) + ") - ambiguous or unsupported");
  }

  var revealTerms = keyTerms(q.reveal);
  var revealHits = revealTerms.filter(function (t) { return pageText.indexOf(t) >= 0; }).length;
  var revealRatio = revealTerms.length ? revealHits / revealTerms.length : 0;
  if (revealRatio < 0.5) notes.push("reveal is largely unsupported by the page (" +
    revealHits + "/" + revealTerms.length + " terms)");

  return {
    ok: identityOk && proximityOk && discriminates && revealRatio >= 0.5,
    identityOk: identityOk, proximityOk: proximityOk, discriminates: discriminates,
    supportCorrect: +sRight.toFixed(2), supportDistractor: +sWrong.toFixed(2),
    revealSupport: +revealRatio.toFixed(2), notes: notes
  };
}

(async function () {
  var batchPath = process.argv[2];
  if (!batchPath) { console.error("usage: flip-verify-sources.js <batch.json>"); process.exit(2); }
  var doc = JSON.parse(fs.readFileSync(path.resolve(batchPath), "utf8"));
  var recs = doc.bank || doc.questions || doc;
  var verified = [], rejected = [];

  for (var i = 0; i < recs.length; i++) {
    var rec = recs[i], q = engine.normalise(rec), reasons = [], detail = null;
    var host = "";
    try { host = new URL(q.sourceUrl).hostname; } catch (e) { reasons.push("source url malformed"); }
    if (host && ALLOW.indexOf(host) < 0) reasons.push("host not on the authoritative allow-list: " + host);

    if (!reasons.length) {
      var res = await fetchText(q.sourceUrl);
      if (res.status !== 200) reasons.push("source did not resolve (HTTP " + res.status +
        (res.note ? ", " + res.note : "") + ")");
      else {
        var title = (res.text.match(/<title[^>]*>([\s\S]*?)<\/title>/i) || [, ""])[1].toLowerCase();
        var c = corroborate(strip(res.text), title, rec);
        detail = c;
        if (!c.ok) c.notes.forEach(function (n) { reasons.push(n); });
      }
    }
    if (reasons.length) rejected.push({ id: q.id, url: q.sourceUrl, reasons: reasons, detail: detail });
    else verified.push(rec);
    console.log((reasons.length ? "REJECT  " : "VERIFY  ") + (q.id || "?").padEnd(24) +
      (q.sourceUrl || "").slice(0, 60));
    if (detail) console.log("        support correct " + detail.supportCorrect +
      " / distractor " + detail.supportDistractor + "   reveal " + detail.revealSupport);
    reasons.forEach(function (r) { console.log("        ! " + r); });
  }

  var outPath = batchPath.replace(/\.json$/, ".verified.json");
  fs.writeFileSync(outPath, JSON.stringify({ bank: verified }, null, 2) + "\n");
  fs.writeFileSync(batchPath.replace(/\.json$/, ".rejected.json"),
    JSON.stringify({ rejected: rejected }, null, 2) + "\n");
  console.log("-".repeat(72));
  console.log("verified " + verified.length + " / " + recs.length +
    "   rejected " + rejected.length);
  console.log("wrote " + path.basename(outPath) + " for the ingest step");
  process.exit(rejected.length && !verified.length ? 1 : 0);
})();
